﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net;
using System.IO;

namespace GetMarketData
{
    //https://www.codeproject.com/Articles/888254/Mining-Webpages-in-Parallel

    public class WebpageDownloader : IDisposable
    {

        public static CancellationToken CancelToken;
        public string LogPath
        {
            get { return this._LogPath; }
            set { this._LogPath = value; }
        }

        private ConcurrentDictionary<string, int> _RequeueCounts = new ConcurrentDictionary<string, int>();
        public BlockingCollection<WebPageItem> Downloads;
        private List<Task<WebPageItem>> _DownloadTasks;
        private List<string> _ReTry = new List<string>();

        private bool _Log = false;
        private string _LogPath = "";
        public readonly object _Locker = new object();
        private int _MaxConcurrentDownloads = 10;
        private int _MaxAttempts = 1;
        private int _TimeoutMs;

        private BlockingCollection<LogMessage> _LogMessages = new BlockingCollection<LogMessage>();
        

        public WebpageDownloader(int MaxConcurrentDownloads = 10, int MaxAttempts = 1, int TimeoutSec = -1, string LogPath = "", bool AppendToLog = false)
        {
            InitCollections();

            Init(MaxConcurrentDownloads, MaxAttempts, TimeoutSec);

            SetLogPath(LogPath, AppendToLog);
        }

        public WebpageDownloader(int MaxConcurrentDownloads = 10, int MaxAttempts = 1, int TimeoutSec = -1)
        {
            InitCollections();

            Init(MaxConcurrentDownloads, MaxAttempts, TimeoutSec);
        }

        private void Init(int MaxConcurrentDownloads = 10, int MaxAttempts = 1, int TimeoutSec = -1)
        {
            _MaxConcurrentDownloads = MaxConcurrentDownloads;
            _MaxAttempts = MaxAttempts;
            _TimeoutMs = TimeoutSec * 1000;
        }

        public void SetLogPath(string LogPath = "", bool AppendToLog = false)
        {
            if (LogPath != "" && LogPath != _LogPath)
            {
                _Log = true;
                _LogPath = LogPath;
                if (AppendToLog == false && File.Exists(_LogPath)) File.Delete(_LogPath);
                StartLogger();
            }
        }

        private void InitCollections()
        {
            Downloads = new BlockingCollection<WebPageItem>(new ConcurrentBag<WebPageItem>());
            CancelToken = new CancellationToken();
            _DownloadTasks = new List<Task <WebPageItem>> ();
        }

        public async void DownloadUrls(string[] URLs, bool binary = false)
        {   //If this is the new set of dl's (not retrys) We must reset our collections and update the log.
            if (_ReTry.Count == 0)
            {
                InitCollections();

                if (File.Exists(_LogPath)) writeToLog("\r\n");
                writeToLog("Downloads Requested: " + URLs.Length + "\r\n" + DateTime.Now + "\r\n" + "###################################################################" + "\r\n");
            }

            int downloadIndex = 0;

            //Create async tasks to download the correct number of URLs concurrently based on 
            //  the _MaxConcurrentDownloads throttle
            int dlCount = URLs.Length <_MaxConcurrentDownloads? URLs.Length: _MaxConcurrentDownloads;
            for (int i = 0; i <dlCount; i++)
            {
                _DownloadTasks.Add(DownloadURL(URLs[i], false, binary));
                downloadIndex++;
            }

            //Process each download as it completes handling errors
            while (_DownloadTasks.Count>0)
            {
                Task <WebPageItem>nextDownload = await Task.WhenAny(_DownloadTasks);
                _DownloadTasks.Remove(nextDownload);

                if (downloadIndex <URLs.Length)
                {
                    _DownloadTasks.Add(DownloadURL(URLs[downloadIndex], false, binary));
                    downloadIndex++;
                }

                WebPageItem download = nextDownload.Result;
                if (download.Error)
                {
                    handleDownloadError(download);
                }
                else
                {
                    writeToLog(download.Url + "|Success" + "\r\n");
                    if (!Downloads.IsAddingCompleted)
                        Downloads.Add(download);
                }
            }

            //Recursively call DownloadUrls until there are no more retrys.
            if (_ReTry.Count>0)
            {
                DownloadUrls(_ReTry.ToArray());
                _ReTry.Clear();
            }
            else
            {
                Downloads.CompleteAdding();
                _RequeueCounts.Clear();
            }
        }

        public async Task<WebPageItem> DownloadURL(string URL, bool log = false, bool binary = false)
        {
            HttpClient client = new HttpClient();
            bool successResponse = false;
            if (_TimeoutMs>0) client.Timeout = TimeSpan.FromMilliseconds(_TimeoutMs);

            try
            {
                using (client)
                using (HttpResponseMessage response = await client.GetAsync(URL, CancelToken).ConfigureAwait(false))
                {
                    successResponse = response.IsSuccessStatusCode;
                    //Throw exception for bad reponse code.
                    response.EnsureSuccessStatusCode();

                    //Download content for good response code.
                    using (HttpContent content = response.Content)
                    {
                        //Get the WebPageItem data .
                        string responseUri = response.RequestMessage.RequestUri.ToString();
                        WebPageItem webpageItem = null;

                        if (binary)
                        {
                            byte[] fileData = await content.ReadAsByteArrayAsync().ConfigureAwait(false);
                            webpageItem = new WebPageItem(URL, fileData, responseUri);
                        }
                        else
                        {
                            string html = await content.ReadAsStringAsync().ConfigureAwait(false);
                            webpageItem = new WebPageItem(URL, html, responseUri);
                        }

                        //Clean up our attempt tracking
                        int attepmts;
                        _RequeueCounts.TryRemove(URL, out attepmts);
                        if (log) writeToLog(URL + "|Success" + "\r\n");
                        return webpageItem;
                    }
                }
            }
            catch (Exception e)
            {
                if (log) writeToLog(URL + "|FAILED|" + e.Message + "\r\n");
                return new WebPageItem(URL, true, e.Message, successResponse);
            }
        }

        /// <summary>
        /// Create a background task to log any errors and retry downloads up to the max attempts.
        /// </summary>
        /// <param name="download"></param>
        public void handleDownloadError(WebPageItem download)
        {
            int attempts = _RequeueCounts.AddOrUpdate(download.Url, 1, (key, oldValue) =>
            {
                return oldValue + 1;
            });
            if (attempts <_MaxAttempts)
            {
                _ReTry.Add(download.Url);
            }
            else
            {
                int attemptsWhenRemoved;
                _RequeueCounts.TryRemove(download.Url, out attemptsWhenRemoved);
                writeToLog(download.Url + "|FAILED MAX ATTEMPTS|" + download.ErrorMessage + "\r\n");
            }
        }

        /// <summary>
        /// Converts a relative url path to absolute url path...
        /// </summary>
        /// <param name="Url"></param>
        /// <param name="RelativePath"></param>
        /// <returns></returns>
        public static string ResolveRelativeUrl(string Url, string RelativePath)
        {
            string fullURl = new Uri(new Uri(Url), RelativePath).AbsoluteUri;
            return fullURl;
        }

        /// <summary>
        /// Async Task to write to the log file
        /// </summary>
        /// <param name="Message"></param>
        public void writeToLog(string Message)
        {
            if (_Log)
            {
                _LogMessages.Add(new LogMessage(_LogPath, Message));
            }
        }

        /// <summary>
        /// Dedicates a single background thread to writing log messages so there is no file contention.
        /// (originally tried a simple lock, but still occastionally ran into file contentions)
        /// </summary>
        public void StartLogger()
        {
            var downloadPages = Task.Factory.StartNew(() =>
            {
                foreach (var logMessage in _LogMessages.GetConsumingEnumerable())
                {
                    File.AppendAllText(logMessage.Filepath, logMessage.Text);
                }
            });
        }

        public static string getBaseLevelDomain(string URL)
        {
            Uri uri = new Uri(URL);
            return uri.Host.Replace("www.", "");
        }

        public void Dispose()
        {
            _LogMessages.CompleteAdding();
        }
    }

    public class WebPageItem
    {
        string _Url;
        string _Html;
        string _ResponseUrl;
        bool _Error;
        string _ErrorMessage;
        bool _ServerSuccessReponse;
        byte[] _FileData;

        public WebPageItem(string Url, string Html, string ResponseUrl)
        {
            _Url = Url;
            _Html = Html;
            _ResponseUrl = ResponseUrl;
            _Error = false;
            _ErrorMessage = "";
            _ServerSuccessReponse = true;
            _FileData = null;
        }

        public WebPageItem(string Url, bool Error, string ErrorMessage, bool ServerSuccessReponse)
        {
            _Url = Url;
            _Html = "";
            _ResponseUrl = "";
            _Error = Error;
            _ErrorMessage = ErrorMessage;
            _ServerSuccessReponse = ServerSuccessReponse;
        }

        public WebPageItem(string Url, byte[] FileData, string ResponseUrl)
        {
            _Url = Url;
            _FileData = FileData;
            _ResponseUrl = ResponseUrl;
            _Error = false;
            _ErrorMessage = "";
            _ServerSuccessReponse = true;
        }

        public byte[] FileData
        {
            get { return _FileData; }
        }

        public string Url
        {
            get { return _Url; }
        }

        public string Html
        {
            get { return _Html; }
        }

        public string ResponseUrl
        {
            get { return _ResponseUrl; }
        }

        public string ErrorMessage
        {
            get { return _ErrorMessage; }
        }

        public bool Error
        {
            get { return _Error; }
        }

        public bool ServerSuccessReponse
        {
            get { return _ServerSuccessReponse; }
        }

        public override string ToString()
        {
            return Url + "\n\t" + Html;
        }
    }

    class LogMessage
    {
        public string Filepath { get; set; }
        public string Text { get; set; }

        public LogMessage(string FilePath, string MessageText)
        {
            Filepath = FilePath;
            Text = MessageText;
        }
    }


}
