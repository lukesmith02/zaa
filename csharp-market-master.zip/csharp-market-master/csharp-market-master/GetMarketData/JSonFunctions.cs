﻿using System.Collections.Generic;
using Newtonsoft.Json;
using System;

namespace GetMarketData
{
    public class JSonFunctions 
    {
        public class MarketData
        {
            public string date { get; set; }
            public string order_count { get; set; }
            public string volume { get; set; }
            public string highest { get; set; }
            public string average { get; set; }
            public string lowest { get; set; }
            public string itemID { get; set; }
            public string itemName { get; set; }
        }

        public class MarketData2
        {
            public string order_id { get; set; }
            public string type_id { get; set; }
            public string location_id { get; set; }
            public string volume_total { get; set; }
            public string volume_remain { get; set; }
            public string min_volume { get; set; }
            public string price { get; set; }
            public string is_buy_order { get; set; }
            public string duration { get; set; }
            public string issued { get; set; }
            public string range { get; set; }
        }

        // get lowest sell order
        // get highest buy order
        // if margin + costs is good then get quantity history for last 10 days and average
        // list buyer and seller count
        // location is 60003760
        
        public static void ReadMarketDataFromJSON(string data, List<JSonFunctions.MarketData> allMarketData, List<TypeInformation> typeIdsAndNames, string readItemID)
        {
            if(readItemID.Equals("22"))
            {
                int temp = 0;
            }
            List<MarketData> marketDataList = JsonConvert.DeserializeObject<List<MarketData>>(data);

            double orderCountAverage = 0.0;
            double volumeAverage = 0.0;
            double highestAverage = 0.0;
            double averageAverage = 0.0;
            double lowestAverage = 0.0;
            int averageCounter = 0;

            foreach(MarketData item in marketDataList)
            {
                DateTime dateInObject = Convert.ToDateTime(item.date);
                DateTime dateNow = DateTime.Now;
                if (Math.Round(dateNow.Subtract(dateInObject).TotalHours, 0) < 49)
                {
                    orderCountAverage += Convert.ToDouble(item.order_count);
                    volumeAverage += Convert.ToDouble(item.volume);
                    highestAverage += Convert.ToDouble(item.highest);
                    averageAverage += Convert.ToDouble(item.average);
                    lowestAverage += Convert.ToDouble(item.lowest);
                    averageCounter++;
                }
            }
            if (averageCounter > 0)
            {
                orderCountAverage /= averageCounter;
                volumeAverage /= averageCounter;
                highestAverage /= averageCounter;
                averageAverage /= averageCounter;
                lowestAverage /= averageCounter;
            }
            MarketData averageItem = new MarketData();
            averageItem.itemID = readItemID;
            string getItemName = "";
            try
            {
                int requiredIndex = typeIdsAndNames.FindIndex(id => id.GetTypeId() == readItemID);
                getItemName = typeIdsAndNames[requiredIndex].GetItemName();
            }
            catch { }

            averageItem.itemName = getItemName;
            averageItem.date = DateTime.Now.ToString();
            averageItem.order_count = orderCountAverage.ToString();
            averageItem.volume = volumeAverage.ToString();
            averageItem.highest = highestAverage.ToString();
            averageItem.average = averageAverage.ToString();
            averageItem.lowest = lowestAverage.ToString();
            if(!averageItem.order_count.Equals("NaN") && !averageItem.order_count.Equals("0") && averageItem.order_count.Length > 0)
            {
                allMarketData.Add(averageItem);
            }
        }
    }
}

/*
  [
  {
    "order_id": 4884813196,
    "type_id": 20213,
    "location_id": 60003760,
    "volume_total": 100,
    "volume_remain": 96,
    "min_volume": 1,
    "price": 6467487,
    "is_buy_order": false,
    "duration": 7,
    "issued": "2017-06-13T07:12:48Z",
    "range": "region"
  },
  {
    "order_id": 4883623309,
    "type_id": 20213,
    "location_id": 60003760,
    "volume_total": 9,
    "volume_remain": 7,
    "min_volume": 1,
    "price": 7499984.99,
    "is_buy_order": false,
    "duration": 7,
    "issued": "2017-06-11T16:24:48Z",
    "range": "region"
  },
  {
    "order_id": 4886112623,
    "type_id": 20213,
    "location_id": 60003760,
    "volume_total": 5,
    "volume_remain": 1,
    "min_volume": 1,
    "price": 6999982.92,
    "is_buy_order": false,
    "duration": 90,
    "issued": "2017-06-08T09:09:51Z",
    "range": "region"
  }
 */
