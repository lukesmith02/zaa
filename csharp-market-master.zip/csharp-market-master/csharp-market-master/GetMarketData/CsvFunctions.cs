﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Old
// Sort by Order Count highest
// Volume >= 500
// Margin >= 25
// Price Diff >= 1000
// Days < 2

// New
// Volume >= 100
// Days <= 1
// Sort by possible profit highest

//Formatting set all to number with comma 2 dp - Lower dp to 0 on Order, Volume, Purchase

namespace GetMarketData
{
    public class CsvFunctions
    {
        public static void CreateCSV(List<JSonFunctions.MarketData> allMarketData, string filePath)
        {
            if(IsFileLocked(new FileInfo(filePath)))
            {
                //System.Threading.Thread.Sleep(5000);
                MessageBox.Show("Close CSV.");
            }

            using (FileStream fileStream = new FileStream(filePath, FileMode.Create, FileAccess.ReadWrite))
            {
                using (var writer = new StreamWriter(fileStream))
                {
                    string header = "Item ID,Item Name,Order Count,Volume,Highest,Average,Lowest,Margin,Price Diff,Daily Profit,Purchase,Days,Possible Profit,Budget";
                    writer.WriteLine(header);

                    int lineCount = 0;
                    foreach (JSonFunctions.MarketData marketData in allMarketData)
                    {
                        string csv = marketData.itemID + "," +
                        marketData.itemName + "," +
                        marketData.order_count + "," +
                        marketData.volume + "," +
                        marketData.highest + "," +
                        marketData.average + "," +
                        marketData.lowest;
                        if(++lineCount == 1)
                        {
                            csv += "," + "=(((E2*0.958)-(G2*1.028))/(E2*0.958))*100";   //Margin value
                            csv += "," + "=E2-G2";   //Price Diff
                            csv += "," + "=((E2*0.958)-(G2*1.028))*D2";   //Daily Profit
                            csv += "," + "=($N$2/16)/(G2*1.028)";   //How many to purchase
                            csv += "," + "=K2/(D2/2)";   //Days it'll take to turnaround
                            csv += "," + "=K2*I2";   //Possible profit to make
                            csv += "," + "800000000";   //Available budget
                        }
                        writer.WriteLine(csv);
                    }
                }
            }
        }

        static bool IsFileLocked(FileInfo file)
        {
            FileStream stream = null;

            try
            {
                stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
            }
            catch (IOException)
            {
                //the file is unavailable because it is:
                //still being written to
                //or being processed by another thread
                //or does not exist (has already been processed)
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }

            //file is not locked
            return false;
        }
    }
}
