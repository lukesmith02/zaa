﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GetMarketData
{
    public class TypeInformation
    {
        private string typeId;
        private string itemName;

        public TypeInformation(string typeId, string itemName)
        {
            this.typeId = typeId;
            this.itemName = itemName;
        }

        public string GetTypeId()
        {
            return typeId;
        }

        public void SetTypeId(string value)
        {
            typeId = value;
        }

        public string GetItemName()
        {
            return itemName;
        }

        public void SetItemName(string value)
        {
            itemName = value;
        }

        public static List<TypeInformation> GetTypdeIds(string inputFileName)
        {
            List<TypeInformation> typeIdsAndNames = new List<TypeInformation>();
            using (FileStream fileStream = new FileStream(inputFileName, FileMode.Open, FileAccess.Read))
            {
                using (var reader = new StreamReader(fileStream))
                {
                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');
                        try
                        {
                            if (values[0].ToString().Length > 0 && values[1].ToString().Length > 0)
                            {
                                typeIdsAndNames.Add(new TypeInformation(values[0].ToString(), values[1].ToString()));
                            }
                        }
                        catch
                        {
                            MessageBox.Show("Couldn't read: " + line.ToString());
                        }
                    }
                }
            }
            return typeIdsAndNames;
        }
    }
}
