﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;


namespace GetMarketData
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());

            List<TypeInformation> typeIdsAndNames = new List<TypeInformation>();
            typeIdsAndNames = TypeInformation.GetTypdeIds(@"C:\Users\PL59163\Desktop\csharp-market-master\Output\typeids.csv");
            Console.WriteLine(typeIdsAndNames);
            List<JSonFunctions.MarketData> allMarketData = new List<JSonFunctions.MarketData>();

            //1. Create a webpage downloader with 100 concurrent 
            //   downloads, 3 retrys, and a 60 second timeout...
            //2. OutputDirectory/downloadLog.txt will have a 
            //   list of all the URLs provided and the outcome 
            //   of each download...
            string outputDirectory = @"C:\Users\PL59163\Desktop\csharp-market-master\Output\";
            WebpageDownloader downloader = new WebpageDownloader(50, 3, 60, outputDirectory + "downloadLog.txt");

            string[] urlList = new string[typeIdsAndNames.Count];
            //string[] urlList = new string[200];
            int indexer = 0;
            foreach (TypeInformation eveType in typeIdsAndNames)
            {
                //string data = @"https://esi.tech.ccp.is/latest/markets/10000002/orders/?datasource=tranquility&order_type=all&type_id=" + eveType.GetTypeId();
                string data = @"https://esi.tech.ccp.is/latest/markets/10000002/history/?datasource=tranquility&type_id=" + eveType.GetTypeId();
                //string data = @"https://esi.tech.ccp.is/latest/markets/10000002/history/?datasource=tranquility&type_id=" + "28364";
                urlList[indexer++] = data;
                if(indexer == 200000)
                {
                    //Exit early - debugging
                    break;
                }
            }

            //Async call to download all of the unique urls provided  
            downloader.DownloadUrls(urlList);

            //Process each webpage as it is downloaded (in parallel).
            int processedCount = 0;
            Parallel.ForEach(downloader.Downloads.GetConsumingEnumerable(), webpageItem =>
            { //Make sure there was no download error...
                if (webpageItem.Error == false)
                {
                    string fileName = Path.GetFileName(webpageItem.Url);
                    string filePath = outputDirectory + fileName;
                    string idNumber = (webpageItem.Url.Substring(webpageItem.Url.IndexOf('?')).Split('&')[1]).Substring(8);
                    if (webpageItem.Html.Length > 0 && idNumber.Length > 0)
                    {
                        JSonFunctions.ReadMarketDataFromJSON(webpageItem.Html.ToString(), allMarketData, typeIdsAndNames, idNumber);
                        Console.Write(processedCount++ + " ");
                        if ((processedCount % 100) == 0)
                            Console.WriteLine();
                    }
                }
            });

            /*
            int earlyBreak = 0;
            foreach (TypeInformation eveType in typeIdsAndNames)
            {
                
                string data = Helper.ReadURLData(@"https://esi.tech.ccp.is/latest/markets/10000002/history/?datasource=tranquility&type_id=" + eveType.GetTypeId());
                if (data.Length > 0)
                {
                    JSonFunctions.ReadMarketDataFromJSON(data, allMarketData, typeIdsAndNames, eveType.GetTypeId());
                }
                
                //string data = Helper.ReadURLData(@"https://esi.tech.ccp.is/latest/markets/10000002/history/?datasource=tranquility&type_id=20");
                //JSonFunctions.ReadMarketDataFromJSON(data, allMarketData, typeIdsAndNames, "20");

                Console.WriteLine(earlyBreak);
                if(earlyBreak++ > 1)
                {
                    break;
                }
            }
            */
            CsvFunctions.CreateCSV(allMarketData, @"C:\Users\PL59163\Desktop\csharp-market-master\Output\JitaMarketData.csv");
            
        }
    }
}
