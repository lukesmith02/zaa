﻿using System;
using System.IO;
using System.Net;
using System.Text;

namespace GetMarketData
{
    class Helper
    {
        public static string ReadURLData(string url)
        {
            string urlAddress = url;
            string data = "";
            ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(AcceptAllCertifications);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(urlAddress);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            if (response.StatusCode == HttpStatusCode.OK)
            {

                WebClient web = new WebClient();
                try
                {
                    Stream stream = web.OpenRead(urlAddress);
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        data = reader.ReadToEnd();
                    }

                } catch { Console.WriteLine("Failed to read: " + urlAddress); }
                response.Close();
            }
            return data;
        }

        public static bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
    }
}
